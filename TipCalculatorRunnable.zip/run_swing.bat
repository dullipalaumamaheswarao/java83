@echo off
setlocal
title Tip Calculator (Universal Swing)
java -cp TipCalculator.jar tipcalculator.TipCalculatorSwingApp
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [ERROR] Application failed to start.
    pause
)
