# Tip Calculator — Runnable Java Desktop Application

A modern, responsive desktop bill & tip calculator built with **JavaFX** and declarative **FXML** layout (with an included universal **Java Swing** fallback).

---

## 🚀 Quick Start (Running the Application)

### Option 1: 1-Click Launch (Recommended)
Double-click `run.bat`.
- Automatically launches the JavaFX graphical interface.
- Includes automatic fallback to the zero-dependency Swing GUI if required.

### Option 2: Dedicated Launchers
- **JavaFX Version**: Run `run_javafx.bat`
- **Universal Swing Version**: Run `run_swing.bat` (works on any standard Java 8+ installation without external modules)

### Option 3: Command Line
```powershell
# Run JavaFX version with bundled modules:
java --module-path lib --add-modules javafx.controls,javafx.fxml -jar TipCalculator.jar

# Run Universal Swing version:
java -cp TipCalculator.jar tipcalculator.TipCalculatorSwingApp
```

---

## 🧮 Calculation Formulas

- **Tip Amount** = `Bill Amount × (Tip Percentage / 100)`
- **Total Bill** = `Bill Amount + Tip Amount`
- **Per Person Share** = `Total Bill / Number of People`

---

## 📁 Package Contents

```
TipCalculatorRunnable/
│
├── TipCalculator.jar              # Precompiled executable JAR
├── run.bat                        # Primary 1-click launcher script
├── run_javafx.bat                 # Direct JavaFX launcher
├── run_swing.bat                  # Zero-dependency Swing launcher
├── TipCalculator_GUI_Preview.png  # Visual preview of the application
├── README.md                      # Documentation & instructions
│
├── lib/                           # OpenJFX 21 runtime libraries
│   ├── javafx-base-21.0.2.jar
│   ├── javafx-base-21.0.2-win.jar
│   ├── javafx-controls-21.0.2.jar
│   ├── javafx-controls-21.0.2-win.jar
│   ├── javafx-fxml-21.0.2.jar
│   ├── javafx-fxml-21.0.2-win.jar
│   ├── javafx-graphics-21.0.2.jar
│   └── javafx-graphics-21.0.2-win.jar
│
└── src/tipcalculator/             # Full source code
    ├── TipCalculatorApp.java      # JavaFX Application entrypoint
    ├── TipCalculatorController.java# FXML event controller & validator
    ├── TipCalculatorLauncher.java # JAR launcher (Application wrapper)
    ├── TipCalculatorSwingApp.java # Standalone Swing fallback GUI
    └── TipCalculator.fxml         # Declarative UI markup
```

---

## 🛠 Recompiling from Source

If you modify the source code, you can recompile using:
```powershell
# Compile JavaFX classes:
javac --module-path lib --add-modules javafx.controls,javafx.fxml -d bin src/tipcalculator/*.java

# Copy FXML resource:
Copy-Item src/tipcalculator/TipCalculator.fxml bin/tipcalculator/

# Package into JAR:
jar --create --file TipCalculator.jar --main-class tipcalculator.TipCalculatorLauncher -C bin .
```
