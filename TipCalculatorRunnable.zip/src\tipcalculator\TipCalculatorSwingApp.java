package tipcalculator;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;

public class TipCalculatorSwingApp extends JFrame {
    private JTextField billField;
    private JTextField peopleField;
    private JComboBox<String> tipCombo;
    private JLabel tipResult;
    private JLabel totalResult;
    private JLabel perPersonResult;
    private JLabel messageLabel;

    public TipCalculatorSwingApp() {
        setTitle("Tip Calculator");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(460, 620);
        setLocationRelativeTo(null);
        setResizable(false);
        getContentPane().setBackground(new Color(244, 247, 251));
        setLayout(new BorderLayout());

        // Header Panel
        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(new BoxLayout(headerPanel, BoxLayout.Y_AXIS));
        headerPanel.setBackground(new Color(29, 78, 216));
        headerPanel.setBorder(new EmptyBorder(26, 24, 26, 24));

        JLabel titleLabel = new JLabel("Tip Calculator");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 26));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel subtitleLabel = new JLabel("Split the bill easily");
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        subtitleLabel.setForeground(new Color(224, 231, 255));
        subtitleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        headerPanel.add(titleLabel);
        headerPanel.add(Box.createRigidArea(new Dimension(0, 6)));
        headerPanel.add(subtitleLabel);
        add(headerPanel, BorderLayout.NORTH);

        // Body Panel
        JPanel bodyPanel = new JPanel();
        bodyPanel.setLayout(new BoxLayout(bodyPanel, BoxLayout.Y_AXIS));
        bodyPanel.setBackground(new Color(244, 247, 251));
        bodyPanel.setBorder(new EmptyBorder(20, 32, 24, 32));

        // Bill Amount
        bodyPanel.add(createFieldLabel("Bill Amount (\u20B9)"));
        bodyPanel.add(Box.createRigidArea(new Dimension(0, 6)));
        billField = new JTextField("1000.00");
        styleTextField(billField);
        bodyPanel.add(billField);
        bodyPanel.add(Box.createRigidArea(new Dimension(0, 14)));

        // Tip Percentage
        bodyPanel.add(createFieldLabel("Tip Percentage"));
        bodyPanel.add(Box.createRigidArea(new Dimension(0, 6)));
        String[] tipOptions = {"5%", "10%", "15%", "18%", "20%", "25%"};
        tipCombo = new JComboBox<>(tipOptions);
        tipCombo.setSelectedItem("15%");
        tipCombo.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        tipCombo.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        tipCombo.setPreferredSize(new Dimension(380, 40));
        tipCombo.setBackground(Color.WHITE);
        bodyPanel.add(tipCombo);
        bodyPanel.add(Box.createRigidArea(new Dimension(0, 14)));

        // Number of People
        bodyPanel.add(createFieldLabel("Number of People"));
        bodyPanel.add(Box.createRigidArea(new Dimension(0, 6)));
        peopleField = new JTextField("2");
        styleTextField(peopleField);
        bodyPanel.add(peopleField);
        bodyPanel.add(Box.createRigidArea(new Dimension(0, 18)));

        // Calculate Button
        JButton calculateButton = new JButton("Calculate");
        calculateButton.setFont(new Font("Segoe UI", Font.BOLD, 16));
        calculateButton.setBackground(new Color(37, 99, 235));
        calculateButton.setForeground(Color.WHITE);
        calculateButton.setFocusPainted(false);
        calculateButton.setBorderPainted(false);
        calculateButton.setOpaque(true);
        calculateButton.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));
        calculateButton.setPreferredSize(new Dimension(380, 46));
        calculateButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        calculateButton.addActionListener(this::calculateTip);
        bodyPanel.add(calculateButton);
        bodyPanel.add(Box.createRigidArea(new Dimension(0, 16)));

        // Results Box
        JPanel resultsPanel = new JPanel();
        resultsPanel.setLayout(new BoxLayout(resultsPanel, BoxLayout.Y_AXIS));
        resultsPanel.setBackground(new Color(239, 246, 255));
        resultsPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(191, 219, 254), 1, true),
                new EmptyBorder(14, 16, 14, 16)
        ));
        resultsPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 120));

        tipResult = new JLabel("Tip: \u20B9150.00");
        tipResult.setFont(new Font("Segoe UI", Font.BOLD, 15));
        tipResult.setForeground(new Color(29, 78, 216));

        totalResult = new JLabel("Total bill: \u20B91150.00");
        totalResult.setFont(new Font("Segoe UI", Font.BOLD, 15));
        totalResult.setForeground(new Color(30, 58, 138));

        perPersonResult = new JLabel("Each person pays: \u20B9575.00");
        perPersonResult.setFont(new Font("Segoe UI", Font.BOLD, 15));
        perPersonResult.setForeground(new Color(30, 58, 138));

        resultsPanel.add(tipResult);
        resultsPanel.add(Box.createRigidArea(new Dimension(0, 6)));
        resultsPanel.add(totalResult);
        resultsPanel.add(Box.createRigidArea(new Dimension(0, 6)));
        resultsPanel.add(perPersonResult);

        bodyPanel.add(resultsPanel);
        bodyPanel.add(Box.createRigidArea(new Dimension(0, 8)));

        // Message Label
        messageLabel = new JLabel(" ");
        messageLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        messageLabel.setForeground(new Color(220, 38, 38));
        messageLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        bodyPanel.add(messageLabel);

        add(bodyPanel, BorderLayout.CENTER);
    }

    private JLabel createFieldLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.BOLD, 14));
        label.setForeground(new Color(30, 41, 59));
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
        return label;
    }

    private void styleTextField(JTextField field) {
        field.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        field.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        field.setPreferredSize(new Dimension(380, 40));
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(203, 213, 225), 1),
                new EmptyBorder(6, 12, 6, 12)
        ));
    }

    private void calculateTip(ActionEvent e) {
        try {
            String billStr = billField.getText().trim();
            String peopleStr = peopleField.getText().trim();

            if (billStr.isEmpty() || peopleStr.isEmpty()) {
                messageLabel.setText("Please fill out both bill amount and people count.");
                return;
            }

            double bill = Double.parseDouble(billStr);
            int people = Integer.parseInt(peopleStr);

            if (bill < 0 || people < 1) {
                messageLabel.setText("Bill must be \u2265 0 and people count \u2265 1.");
                return;
            }

            String tipStr = (String) tipCombo.getSelectedItem();
            int percentage = Integer.parseInt(tipStr.replace("%", "").trim());

            double tip = bill * percentage / 100.0;
            double total = bill + tip;
            double perPerson = total / people;

            tipResult.setText(String.format("Tip: \u20B9%.2f", tip));
            totalResult.setText(String.format("Total bill: \u20B9%.2f", total));
            perPersonResult.setText(String.format("Each person pays: \u20B9%.2f", perPerson));
            messageLabel.setText(" ");
        } catch (NumberFormatException ex) {
            messageLabel.setText("Please enter valid numeric values.");
        }
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}

        SwingUtilities.invokeLater(() -> {
            new TipCalculatorSwingApp().setVisible(true);
        });
    }
}
