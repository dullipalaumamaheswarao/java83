package tipcalculator;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class TipCalculatorController {
    @FXML private TextField billField;
    @FXML private TextField peopleField;
    @FXML private ComboBox<Integer> tipCombo;
    @FXML private Button calculateButton;
    @FXML private Label tipResult;
    @FXML private Label totalResult;
    @FXML private Label perPersonResult;
    @FXML private Label messageLabel;

    @FXML
    private void initialize() {
        tipCombo.getItems().addAll(5, 10, 15, 18, 20, 25);
        tipCombo.setValue(15);
        peopleField.setText("1");
        calculateButton.setOnAction(event -> calculateTip());
    }

    private void calculateTip() {
        try {
            String billText = billField.getText() != null ? billField.getText().trim() : "";
            String peopleText = peopleField.getText() != null ? peopleField.getText().trim() : "";

            if (billText.isEmpty() || peopleText.isEmpty()) {
                messageLabel.setText("Please enter both bill amount and number of people.");
                return;
            }

            double bill = Double.parseDouble(billText);
            int people = Integer.parseInt(peopleText);
            Integer percentage = tipCombo.getValue();

            if (!Double.isFinite(bill) || bill < 0) {
                messageLabel.setText("Please enter a valid positive bill amount.");
                return;
            }

            if (people < 1) {
                messageLabel.setText("Number of people must be at least 1.");
                return;
            }

            if (percentage == null) {
                messageLabel.setText("Please choose a tip percentage.");
                return;
            }

            double tip = bill * percentage / 100.0;
            double total = bill + tip;
            double perPerson = total / people;

            tipResult.setText(String.format("Tip: \u20B9%.2f", tip));
            totalResult.setText(String.format("Total bill: \u20B9%.2f", total));
            perPersonResult.setText(String.format("Each person pays: \u20B9%.2f", perPerson));
            messageLabel.setText("");
        } catch (NumberFormatException ex) {
            messageLabel.setText("Please enter valid numbers in the bill and people fields.");
        }
    }
}
