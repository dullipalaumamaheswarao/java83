package tipcalculator;

/**
 * Launcher class that does not extend javafx.application.Application.
 * This avoids the JavaFX runtime components missing error when launching from an executable JAR.
 */
public class TipCalculatorLauncher {
    public static void main(String[] args) {
        TipCalculatorApp.main(args);
    }
}
