@echo off
setlocal
title Tip Calculator (JavaFX)
java --module-path lib --add-modules javafx.controls,javafx.fxml -jar TipCalculator.jar
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [ERROR] JavaFX failed to start.
    echo If your system lacks hardware graphics acceleration, run 'run_swing.bat' instead.
    pause
)
