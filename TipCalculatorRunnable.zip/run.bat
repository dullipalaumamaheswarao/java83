@echo off
setlocal
title Tip Calculator Launcher
echo ===================================================
echo           TIP CALCULATOR - RUNNABLE LAUNCHER
echo ===================================================
echo.

where java >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Java was not found in your system PATH!
    echo Please install Java 17+ or Java 24 to run this application.
    echo Download: https://adoptium.net/
    echo.
    pause
    exit /b 1
)

echo Starting Tip Calculator (JavaFX)...
java --module-path lib --add-modules javafx.controls,javafx.fxml -jar TipCalculator.jar
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [INFO] JavaFX launcher exited or encountered an environment constraint.
    echo [INFO] Launching Universal Java GUI (Swing fallback)...
    echo.
    java -cp TipCalculator.jar tipcalculator.TipCalculatorSwingApp
    if %ERRORLEVEL% NEQ 0 (
        echo.
        echo [ERROR] Application failed to start.
        pause
    )
)
