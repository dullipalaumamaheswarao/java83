package tipcalculator;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class TipCalculatorApp extends Application {
    @Override
    public void start(Stage primaryStage) {
        try {
            java.net.URL fxmlUrl = getClass().getResource("/tipcalculator/TipCalculator.fxml");
            if (fxmlUrl == null) {
                fxmlUrl = getClass().getResource("TipCalculator.fxml");
            }
            if (fxmlUrl == null) {
                throw new RuntimeException("Could not locate TipCalculator.fxml resource file.");
            }

            Parent root = FXMLLoader.load(fxmlUrl);
            Scene scene = new Scene(root, 480, 620);

            primaryStage.setTitle("Tip Calculator — JavaFX");
            primaryStage.setScene(scene);
            primaryStage.setResizable(false);
            primaryStage.centerOnScreen();
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Failed to launch JavaFX UI: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
