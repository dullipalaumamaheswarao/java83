Tip Calculator — JavaFX GUI

Included:
- TipCalculator.fxml: GUI layout built from Label, TextField, ComboBox, and Button.
- TipCalculatorController.java: responds to Calculate button clicks and validates input.
- TipCalculator_GUI_Preview.png: visual preview of the GUI.

Calculation:
Tip = bill × tip percentage / 100
Total = bill + tip
Per person = total / number of people

To run:
1. Use a JavaFX project in IntelliJ IDEA or another JavaFX-enabled IDE.
2. Put TipCalculator.fxml in src/main/resources/tipcalculator/ .
3. Put TipCalculatorController.java in src/main/java/tipcalculator/ .
4. Load /tipcalculator/TipCalculator.fxml from your JavaFX Application start() method.
5. Make sure JavaFX Controls and FXML modules are configured.

This project needs JavaFX runtime; it will not run in a plain online Java compiler without JavaFX.
