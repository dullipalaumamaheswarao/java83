package tipcalculator;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class TipCalculatorController {
    @FXML private TextField billField;
    @FXML private TextField peopleField;
    @FXML private ComboBox<Integer> tipCombo;
    @FXML private Button calculateButton;
    @FXML private Label tipResult;
    @FXML private Label totalResult;
    @FXML private Label perPersonResult;
    @FXML private Label messageLabel;

    @FXML
    private void initialize() {
        tipCombo.getItems().addAll(5, 10, 15, 18, 20, 25);
        tipCombo.setValue(15);
        peopleField.setText("1");
        calculateButton.setOnAction(event -> calculateTip());
    }

    private void calculateTip() {
        try {
            double bill = Double.parseDouble(billField.getText().trim());
            int people = Integer.parseInt(peopleField.getText().trim());
            Integer percentage = tipCombo.getValue();

            if (!Double.isFinite(bill) || bill < 0 || people < 1 || percentage == null) {
                messageLabel.setText("Enter a valid bill, tip percentage, and people count.");
                return;
            }

            double tip = bill * percentage / 100.0;
            double total = bill + tip;
            double perPerson = total / people;

            tipResult.setText(String.format("Tip: ₹%.2f", tip));
            totalResult.setText(String.format("Total bill: ₹%.2f", total));
            perPersonResult.setText(String.format("Each person pays: ₹%.2f", perPerson));
            messageLabel.setText("");
        } catch (NumberFormatException ex) {
            messageLabel.setText("Please enter numbers in the bill and people fields.");
        }
    }
}
